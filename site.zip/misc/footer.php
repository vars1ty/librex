<div class="footer-container">
    <a href="./">LibreX</a>
    <a href="https://github.com/vars1ty/librex/" target="_blank">Source</a>
    <a href="https://github.com/hnhx/librex/blob/main/README.md" target="_blank">Instance list</a>
    <a href="./settings.php">Settings</a>
    <a href="./api.php" target="_blank">API</a>
    <a href="./donate.php">Donate ❤️</a>
</div>
<div class="bottom-container">
    <small>session for contact: <code>05f1c94c6536a01a1533768d38dc746dce1583307db90a0a943080fefbe6292d07</code></small>
</div>